package com.example.scorekeeper;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    //final Activity mActivity = this;

    Button homeTallyBtn = findViewById(R.id.homeTallyBtn);
    Button awayTallyBtn = findViewById(R.id.awayTallyBtn);
    Button resetBtn = findViewById(R.id.resetBtn);
    TextView homeScore = findViewById(R.id.homeScore);
    TextView awayScore = findViewById(R.id.awayScore);
    Integer currentHomeScore;
    Integer currentAwayScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        homeTallyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentHomeScore = Integer.parseInt(homeScore.getText().toString());
                currentHomeScore++;
                homeScore.setText(currentHomeScore);
            }
        });

        awayTallyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentAwayScore = Integer.parseInt(awayScore.getText().toString());
                currentAwayScore++;
                awayScore.setText(currentAwayScore);
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                homeScore.setText("0");
                awayScore.setText("0");
            }
        });
    }
}
